# Pong Game
Pong Game - C++ and SDL2

![Ball bounces off the paddles](https://user-images.githubusercontent.com/28037427/218172815-d77ac498-35dd-4dc2-81b0-96845a98ec1b.jpg)

![Game-end condition](https://user-images.githubusercontent.com/28037427/218172832-51e6a065-ac27-4141-8032-fc82464bcf5e.jpg)

![Ball misses AI paddle](https://user-images.githubusercontent.com/28037427/218172847-a73e38ed-c5bb-4b25-9fa2-b60c3dd94a1d.jpg)

![Game-end condition 2](https://user-images.githubusercontent.com/28037427/218172858-32f722bb-dbf2-4a7c-9978-6b9b6360577f.jpg)
